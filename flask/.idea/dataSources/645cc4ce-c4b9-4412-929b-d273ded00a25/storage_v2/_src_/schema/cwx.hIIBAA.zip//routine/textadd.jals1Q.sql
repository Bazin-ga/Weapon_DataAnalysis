create
    definer = root@localhost procedure textadd(IN lan char(30))
BEGIN
INSERT INTO text(Language) VALUES(lan);
END;

