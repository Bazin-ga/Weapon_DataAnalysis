create
    definer = root@localhost procedure textaddall(IN author char(30), IN lan char(30), IN face char(30))
BEGIN
INSERT INTO text(Author,Language,Face) VALUES(author,lan,face);
END;

