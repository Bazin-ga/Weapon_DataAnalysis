create
    definer = root@localhost procedure textdel(IN lan char(30))
BEGIN
    delete from text where Language=lan;
END;

