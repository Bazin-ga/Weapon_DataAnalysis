create
    definer = root@localhost procedure textsearch(IN f varchar(20))
BEGIN
    select * from text where Face=f;
END;

