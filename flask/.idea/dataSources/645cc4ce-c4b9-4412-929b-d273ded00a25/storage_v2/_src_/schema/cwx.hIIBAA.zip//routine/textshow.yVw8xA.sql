create
    definer = root@localhost procedure textshow()
BEGIN
    select * from text;
END;

