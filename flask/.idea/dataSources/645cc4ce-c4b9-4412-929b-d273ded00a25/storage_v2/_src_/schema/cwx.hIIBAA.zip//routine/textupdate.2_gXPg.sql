create
    definer = root@localhost procedure textupdate(IN lan varchar(30), IN uptlan varchar(30))
BEGIN
    update text set Language=uptlan where Language=lan;
END;

